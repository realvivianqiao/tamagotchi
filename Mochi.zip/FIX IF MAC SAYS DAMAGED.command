#!/bin/bash
cd "$(dirname "$0")"
xattr -cr "Mochi.app"
open "Mochi.app"
