MOCHI
If damaged: open FIX IF MAC SAYS DAMAGED.command
