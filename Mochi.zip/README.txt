MOCHI

If Mac says damaged: open FIX IF MAC SAYS DAMAGED.command
Hide pet: 🐶 menu → Hide pet (focus mode)
