MOCHI

1. Open Mochi.app
2. If Mac says "damaged": double-click FIX IF MAC SAYS DAMAGED.command
3. Too distracting? Click 😴 in the menu bar → Show pet later, or 🐶 → Hide pet (focus mode)
