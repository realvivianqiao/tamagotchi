MOCHI

1. If Mochi.app opens — you’re done.
2. If Mac says “damaged”:
   double-click “FIX IF MAC SAYS DAMAGED.command”
   (click Open if prompted)

That’s Gatekeeper blocking unsigned downloads — the app isn’t actually broken.
